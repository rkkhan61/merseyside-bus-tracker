//
//  MapViewController.swift
//  Merseyside_bus
//
//  Created by Shivansh Raj on 12/04/2025.
//

import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController, CLLocationManagerDelegate, UITableViewDataSource, UITableViewDelegate, MKMapViewDelegate {

    @IBOutlet weak var startTF: UITextField!
    @IBOutlet weak var endTF: UITextField!
    @IBOutlet weak var timeTF: UITextField!
    @IBOutlet weak var myMap: MKMapView!
    @IBOutlet weak var tableView: UITableView!
    
    var routes: [(name: String, stops: [BusStop])] = []
    var expandedIndexSet: Set<Int> = []
    var highlightedRouteIndex: Int? = nil
    
    var busAnnotation: MKPointAnnotation? = nil
    var busTimer: Timer?
    var busPathCoordinates: [CLLocationCoordinate2D] = []
    var currentBusIndex: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myMap.delegate = self
        tableView.dataSource = self
        tableView.delegate = self
                
        loadBusData()
    }
    
    func loadBusData() {
        if let url = Bundle.main.url(forResource: "BusStopsSuper", withExtension: "json") {
            do {
                let data = try Data(contentsOf: url)
                let decodedData = try JSONDecoder().decode(SuperBusData.self, from: data)
                
                for (routeName, superRoute) in decodedData.routes {
                    routes.append((name: routeName, stops: superRoute.stops))
                }
                
                self.tableView.reloadData()
            } catch {
                print("Error decoding JSON: \(error)")
            }
        } else {
            print("BusStopsSuper.json file not found")
        }
    }
    
    @IBAction func goButton(_ sender: Any) {
        view.endEditing(true)
        findBestRoute()
    }
    
    func findBestRoute() {
        guard let startText = startTF.text?.lowercased(),
              let endText = endTF.text?.lowercased(),
              !startText.isEmpty,
              !endText.isEmpty else {
            print("Start or End text field is empty.")
            return
        }
        
        highlightedRouteIndex = nil
        
        for (index, route) in routes.enumerated() {
            let stopNames = route.stops.map { $0.stop_name.lowercased() }
            
            if let startIndex = stopNames.firstIndex(where: { $0.contains(startText) }),
               let endIndex = stopNames.firstIndex(where: { $0.contains(endText) }),
               startIndex < endIndex {
                
                if let userTime = timeTF.text, !userTime.isEmpty {
                    let matchingTimes = route.stops[startIndex].times.filter { $0 >= userTime }
                    if matchingTimes.isEmpty {
                        continue
                    }
                }
                
                highlightedRouteIndex = index
                drawRouteOnMap(stops: Array(route.stops[startIndex...endIndex]))
                break
            }
        }
        
        tableView.reloadData()
        if let index = highlightedRouteIndex {
            let indexPath = IndexPath(row: index, section: 0)
            tableView.scrollToRow(at: indexPath, at: .top, animated: true)

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                if let cell = self.tableView.cellForRow(at: indexPath) {
                    UIView.animate(withDuration: 0.5, animations: {
                        cell.backgroundColor = UIColor.systemYellow.withAlphaComponent(0.5)
                    }) { _ in
                        UIView.animate(withDuration: 0.5) {
                            cell.backgroundColor = UIColor.systemBlue.withAlphaComponent(0.3)
                        }
                    }
                }
            }
        }
    }
    
    func drawRouteOnMap(stops: [BusStop]) {
        myMap.removeAnnotations(myMap.annotations)
        myMap.removeOverlays(myMap.overlays)
        
        var coordinates: [CLLocationCoordinate2D] = []
        
        for stop in stops {
            let coordinate = CLLocationCoordinate2D(latitude: stop.latitude, longitude: stop.longitude)
            coordinates.append(coordinate)
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = coordinate
            annotation.title = stop.stop_name
            myMap.addAnnotation(annotation)
        }
        
        // Draw polyline
        let polyline = MKPolyline(coordinates: coordinates, count: coordinates.count)
        myMap.addOverlay(polyline)
        
        // Zoom map to fit route
        if let first = coordinates.first {
            var region = MKCoordinateRegion(center: first, latitudinalMeters: 3000, longitudinalMeters: 3000)
            myMap.setRegion(region, animated: true)
        }
        
        // Set up bus animation
        busPathCoordinates = coordinates
        currentBusIndex = 0
        startBusSimulation()
    }
    
    func startBusSimulation() {
        busTimer?.invalidate()
        
        busAnnotation = MKPointAnnotation()
        busAnnotation?.coordinate = busPathCoordinates.first ?? CLLocationCoordinate2D()
        busAnnotation?.title = "Bus"
        if let busAnnotation = busAnnotation {
            myMap.addAnnotation(busAnnotation)
        }
        
        busTimer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(moveBus), userInfo: nil, repeats: true)
    }
    
    @objc func moveBus() {
        guard currentBusIndex < busPathCoordinates.count else {
            busTimer?.invalidate()
            return
        }
        
        let nextCoord = busPathCoordinates[currentBusIndex]
        
        UIView.animate(withDuration: 1.5) {
            self.busAnnotation?.coordinate = nextCoord
        }
        
        currentBusIndex += 1
    }
    
    // MARK: - MapKit Overlay Renderer
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if let polyline = overlay as? MKPolyline {
            let renderer = MKPolylineRenderer(polyline: polyline)
            renderer.strokeColor = UIColor.systemBlue
            renderer.lineWidth = 4
            return renderer
        }
        return MKOverlayRenderer(overlay: overlay)
    }
    
    // MARK: - TableView Data Source & Delegate
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return routes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        let route = routes[indexPath.row]

        let attributedText = NSMutableAttributedString()

        let isExpanded = expandedIndexSet.contains(indexPath.row)
        let expandIcon = isExpanded ? "➖" : "➕"

        let routeTitleAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.boldSystemFont(ofSize: 18)
        ]
        let title = NSAttributedString(string: "\(expandIcon) \(route.name)\n", attributes: routeTitleAttributes)
        attributedText.append(title)

        if isExpanded {
            let stopAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 16)
            ]
            for stop in route.stops {
                let stopLine = NSAttributedString(string: "   • \(stop.stop_name)\n", attributes: stopAttributes)
                attributedText.append(stopLine)
            }
        }

        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.attributedText = attributedText

        if highlightedRouteIndex == indexPath.row {
            cell.backgroundColor = UIColor.systemBlue.withAlphaComponent(0.3)
        } else {
            cell.backgroundColor = UIColor.clear
        }

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)

        if expandedIndexSet.contains(indexPath.row) {
            expandedIndexSet.remove(indexPath.row)
        } else {
            expandedIndexSet.insert(indexPath.row)
        }

        tableView.reloadRows(at: [indexPath], with: .automatic)
    }
}
